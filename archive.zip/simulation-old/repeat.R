rm(list = ls())
setwd("~/2023pb-tsroc/simulation-0401-2")

##
## CALCULATE ALPHA
##
## SIMULATE RESULTS
##


setwd("~/2023pb-tsroc/simulation-0401-2/exp0.2/a-calc/")
source("simu.repeat.a.R")

setwd("~/2023pb-tsroc/simulation-0401-2/exp0.2/")
source("1000-times-simulation.R")





setwd("~/2023pb-tsroc/simulation-0401-2/U14/a-calc/")
source("simu.repeat.a.R")

setwd("~/2023pb-tsroc/simulation-0401-2/U14")
source("1000-times-simulation.R")

